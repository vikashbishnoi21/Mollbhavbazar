import { Link } from "react-router-dom";
import { useApp } from "../context/AppContext";

const Navbar = () => {
  const { cartCount } = useApp();

  return (
    <header className="sticky top-0 z-50 border-b border-emerald-100 bg-white/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
        <Link to="/" className="text-xl font-bold text-primary">
          BasketCheck
        </Link>
        <Link to="/list" className="pill-btn bg-emerald-100 text-emerald-700">
          Cart {cartCount}
        </Link>
      </div>
    </header>
  );
};

export default Navbar;
