import { useMemo, useState } from "react";

const ComparisonTable = ({ comparison, onBuy }) => {
  const [availableOnly, setAvailableOnly] = useState(false);
  const { platforms, items, totals, bestOverall } = comparison;

  const filteredItems = useMemo(() => {
    if (!availableOnly) return items;
    return items.filter((item) => platforms.some((p) => item.prices[p.id]?.available));
  }, [availableOnly, items, platforms]);

  return (
    <section className="card space-y-4 animate-slidein">
      <div className="flex items-center justify-between gap-3">
        <h2 className="text-lg font-semibold">Price Comparison</h2>
        <label className="text-sm text-gray-600">
          <input
            type="checkbox"
            checked={availableOnly}
            onChange={(e) => setAvailableOnly(e.target.checked)}
            className="mr-2"
          />
          Show only available items
        </label>
      </div>

      <div className="rounded-xl bg-emerald-50 p-3 text-sm text-emerald-800">
        Best Overall Deal: <span className="font-semibold">{bestOverall}</span>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full text-sm">
          <thead>
            <tr className="border-b border-gray-200 text-left">
              <th className="px-2 py-2">Item</th>
              {platforms.map((platform) => (
                <th key={platform.id} className="px-2 py-2">
                  <div className="font-semibold">{platform.name}</div>
                  <div className="text-xs text-gray-500">
                    {platform.deliveryTime} | Fee Rs {platform.deliveryFee}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filteredItems.map((item, idx) => (
              <tr key={`${item.name}-${idx}`} className="border-b border-gray-100">
                <td className="px-2 py-3 font-medium">
                  {item.name} {item.quantity}
                  {item.unit}
                </td>
                {platforms.map((platform) => {
                  const cell = item.prices[platform.id];
                  if (!cell?.available) {
                    return (
                      <td key={platform.id} className="px-2 py-3 text-gray-400 line-through">
                        Not available
                      </td>
                    );
                  }
                  const isBest = item.bestPlatform === platform.id;
                  const css = isBest ? "text-green-700" : "text-red-500";
                  return (
                    <td key={platform.id} className={`px-2 py-3 font-semibold ${css}`}>
                      Rs {cell.price} {isBest ? "BEST" : ""}
                    </td>
                  );
                })}
              </tr>
            ))}
            <tr className="bg-gray-50">
              <td className="px-2 py-3 font-bold">TOTAL</td>
              {platforms.map((platform) => (
                <td key={platform.id} className="px-2 py-3 font-bold">
                  Rs {totals[platform.id]}
                  <button
                    onClick={() => onBuy(platform.id)}
                    className="ml-2 rounded-lg bg-accent px-2 py-1 text-xs text-white"
                  >
                    BUY
                  </button>
                </td>
              ))}
            </tr>
          </tbody>
        </table>
      </div>
    </section>
  );
};

export default ComparisonTable;
