import { Link, useLocation } from "react-router-dom";

const links = [
  { to: "/", label: "Home" },
  { to: "/list", label: "Search" },
  { to: "/compare", label: "Comparison" },
  { to: "/checkout", label: "Cart" }
];

const MobileNav = () => {
  const { pathname } = useLocation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 border-t border-gray-200 bg-white md:hidden">
      <div className="grid grid-cols-4">
        {links.map((link) => {
          const active = pathname === link.to;
          return (
            <Link
              key={link.to}
              to={link.to}
              className={`py-3 text-center text-xs font-semibold ${active ? "text-primary" : "text-gray-500"}`}
            >
              {link.label}
            </Link>
          );
        })}
      </div>
    </nav>
  );
};

export default MobileNav;
