import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { searchFromImage, searchFromText, searchFromVoice } from "../services/api";
import { useApp } from "../context/AppContext";

const TABS = ["Image Search", "Voice Search", "Text Search"];

const SearchTabs = () => {
  const [active, setActive] = useState(TABS[0]);
  const [textValue, setTextValue] = useState("");
  const [voiceTranscript, setVoiceTranscript] = useState("");
  const [listening, setListening] = useState(false);
  const [loading, setLoading] = useState(false);
  const { setItems, setImageMeta, setToast } = useApp();
  const navigate = useNavigate();

  const SpeechRecognition = useMemo(
    () => window.SpeechRecognition || window.webkitSpeechRecognition,
    []
  );

  const goToList = (nextItems) => {
    setItems(nextItems);
    navigate("/list");
  };

  const parseText = async () => {
    try {
      setLoading(true);
      const data = await searchFromText(textValue);
      goToList(data.items || []);
    } catch (err) {
      setToast(err.message);
    } finally {
      setLoading(false);
    }
  };

  const parseVoice = async (transcript) => {
    try {
      setLoading(true);
      const data = await searchFromVoice(transcript);
      goToList(data.items || []);
    } catch (err) {
      setToast(err.message);
    } finally {
      setLoading(false);
    }
  };

  const startVoiceCapture = () => {
    if (!SpeechRecognition) {
      setToast("Web Speech API is not supported in this browser.");
      return;
    }
    const recognition = new SpeechRecognition();
    recognition.lang = "en-IN";
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    setListening(true);
    recognition.start();
    recognition.onresult = (event) => {
      const transcript = event.results?.[0]?.[0]?.transcript || "";
      setVoiceTranscript(transcript);
      parseVoice(transcript);
    };
    recognition.onerror = () => setToast("Could not capture voice. Try again.");
    recognition.onend = () => setListening(false);
  };

  const onImageSelect = async (file) => {
    if (!file) return;
    try {
      setLoading(true);
      const preview = URL.createObjectURL(file);
      const data = await searchFromImage(file);
      setImageMeta({ preview, boxes: data.boxes || [] });
      goToList(data.items || []);
    } catch (err) {
      setToast(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="card overflow-hidden">
      <div className="mb-4 flex flex-wrap gap-2">
        {TABS.map((tab) => (
          <button
            key={tab}
            className={`pill-btn ${active === tab ? "bg-primary text-white" : "bg-emerald-50 text-emerald-700"}`}
            onClick={() => setActive(tab)}
          >
            {tab}
          </button>
        ))}
      </div>

      <div className="min-h-44 animate-slidein">
        {active === "Image Search" && (
          <div className="space-y-3">
            <input
              type="file"
              accept="image/png,image/jpg,image/jpeg"
              onChange={(e) => onImageSelect(e.target.files?.[0])}
              className="w-full rounded-xl border border-emerald-200 p-2"
            />
            <p className="text-sm text-gray-500">Upload JPG/PNG to auto-detect grocery items.</p>
          </div>
        )}

        {active === "Voice Search" && (
          <div className="space-y-3">
            <button onClick={startVoiceCapture} className="pill-btn bg-accent text-white">
              {listening ? "Listening..." : "Record Voice"}
            </button>
            <textarea
              value={voiceTranscript}
              readOnly
              className="h-24 w-full rounded-xl border border-gray-200 p-3"
              placeholder="Your spoken items will appear here..."
            />
          </div>
        )}

        {active === "Text Search" && (
          <div className="space-y-3">
            <textarea
              value={textValue}
              onChange={(e) => setTextValue(e.target.value)}
              className="h-32 w-full rounded-xl border border-gray-200 p-3"
              placeholder="onions 2kg, milk 1L, bread large"
            />
            <button onClick={parseText} className="pill-btn bg-accent text-white">
              Parse Item List
            </button>
          </div>
        )}
      </div>

      {loading && (
        <div className="mt-4 flex items-center gap-3 text-sm text-gray-600">
          <div className="spinner" />
          Fetching basket details...
        </div>
      )}
    </section>
  );
};

export default SearchTabs;
