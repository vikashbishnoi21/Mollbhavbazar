const SkeletonCard = () => {
  return (
    <div className="card animate-pulse">
      <div className="mb-3 h-4 w-1/3 rounded bg-gray-200" />
      <div className="mb-2 h-3 rounded bg-gray-200" />
      <div className="h-3 w-2/3 rounded bg-gray-200" />
    </div>
  );
};

export default SkeletonCard;
