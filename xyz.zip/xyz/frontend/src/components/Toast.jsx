import { useEffect } from "react";
import { useApp } from "../context/AppContext";

const Toast = () => {
  const { toast, setToast } = useApp();

  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(null), 2500);
    return () => clearTimeout(timer);
  }, [toast, setToast]);

  if (!toast) return null;
  return (
    <div className="fixed right-4 top-20 z-[100] rounded-xl bg-gray-900 px-4 py-2 text-sm text-white shadow-xl">
      {toast}
    </div>
  );
};

export default Toast;
