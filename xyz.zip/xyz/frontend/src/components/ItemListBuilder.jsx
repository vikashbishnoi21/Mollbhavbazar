import { useState } from "react";
import { getSuggestions } from "../services/api";

const DEFAULT_ROW = { name: "", quantity: 1, unit: "kg", size: "medium" };
const UNIT_OPTIONS = ["small", "medium", "large", "250g", "500g", "1kg", "2kg", "1l", "2l", "kg", "g"];

const ItemListBuilder = ({ items, onChange, onSearch }) => {
  const [suggestions, setSuggestions] = useState([]);

  const updateRow = (index, key, value) => {
    const next = [...items];
    next[index] = { ...next[index], [key]: value };
    onChange(next);
  };

  const removeRow = (index) => onChange(items.filter((_, idx) => idx !== index));
  const addRow = () => onChange([...items, { ...DEFAULT_ROW }]);

  const handleNameInput = async (index, value) => {
    updateRow(index, "name", value.toLowerCase());
    if (value.length < 2) return setSuggestions([]);
    try {
      const data = await getSuggestions(value);
      setSuggestions(data.suggestions || []);
    } catch {
      setSuggestions([]);
    }
  };

  return (
    <section className="card space-y-3">
      {items.map((item, idx) => (
        <div key={`${item.name}-${idx}`} className="grid grid-cols-12 gap-2">
          <div className="col-span-5">
            <input
              value={item.name}
              onChange={(e) => handleNameInput(idx, e.target.value)}
              className="w-full rounded-xl border border-gray-200 px-3 py-2"
              placeholder="Item name"
            />
          </div>
          <div className="col-span-2">
            <input
              type="number"
              min="1"
              value={item.quantity}
              onChange={(e) => updateRow(idx, "quantity", Number(e.target.value))}
              className="w-full rounded-xl border border-gray-200 px-3 py-2"
            />
          </div>
          <div className="col-span-4">
            <select
              value={item.unit || "medium"}
              onChange={(e) => {
                updateRow(idx, "unit", e.target.value);
                updateRow(idx, "size", e.target.value);
              }}
              className="w-full rounded-xl border border-gray-200 px-3 py-2"
            >
              {UNIT_OPTIONS.map((unit) => (
                <option key={unit} value={unit}>
                  {unit}
                </option>
              ))}
            </select>
          </div>
          <button
            onClick={() => removeRow(idx)}
            className="col-span-1 rounded-xl bg-red-100 px-2 py-2 font-semibold text-red-700"
          >
            x
          </button>
        </div>
      ))}

      {suggestions.length > 0 && (
        <div className="rounded-xl border border-emerald-100 bg-emerald-50 p-2 text-sm text-emerald-700">
          Suggestions: {suggestions.join(", ")}
        </div>
      )}

      <div className="flex flex-wrap gap-2">
        <button onClick={addRow} className="pill-btn bg-emerald-100 text-emerald-700">
          + Add item manually
        </button>
        <button onClick={onSearch} className="pill-btn bg-accent text-white">
          Search Prices
        </button>
      </div>
    </section>
  );
};

export default ItemListBuilder;
