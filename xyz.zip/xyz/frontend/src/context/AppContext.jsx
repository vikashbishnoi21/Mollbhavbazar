import { createContext, useContext, useMemo, useState } from "react";

const AppContext = createContext(null);

export const AppProvider = ({ children }) => {
  const [items, setItems] = useState([]);
  const [comparison, setComparison] = useState(null);
  const [selectedPlatform, setSelectedPlatform] = useState("");
  const [toast, setToast] = useState(null);
  const [pincode, setPincode] = useState(localStorage.getItem("basketcheck_pincode") || "");
  const [imageMeta, setImageMeta] = useState({ preview: "", boxes: [] });
  const [order, setOrder] = useState(null);

  const cartCount = items.length;
  const value = useMemo(
    () => ({
      items,
      setItems,
      comparison,
      setComparison,
      selectedPlatform,
      setSelectedPlatform,
      toast,
      setToast,
      cartCount,
      pincode,
      setPincode,
      imageMeta,
      setImageMeta,
      order,
      setOrder
    }),
    [items, comparison, selectedPlatform, toast, cartCount, pincode, imageMeta, order]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export const useApp = () => useContext(AppContext);
