import { useNavigate } from "react-router-dom";
import { useApp } from "../context/AppContext";
import ItemListBuilder from "../components/ItemListBuilder";
import { comparePrices } from "../services/api";
import { useState } from "react";
import SkeletonCard from "../components/SkeletonCard";

const ListPage = () => {
  const { items, setItems, setComparison, pincode, setPincode, setToast, imageMeta } = useApp();
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const runComparison = async () => {
    try {
      setLoading(true);
      localStorage.setItem("basketcheck_pincode", pincode);
      const data = await comparePrices(items, pincode);
      setComparison(data);
      navigate("/compare");
    } catch (err) {
      setToast(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <section className="card">
        <label className="mb-2 block text-sm font-medium text-gray-700">Delivery Pincode</label>
        <input
          value={pincode}
          onChange={(e) => setPincode(e.target.value)}
          className="w-full rounded-xl border border-gray-200 px-3 py-2"
          placeholder="Enter 6-digit pincode"
        />
      </section>

      {imageMeta.preview && (
        <section className="card">
          <h3 className="mb-2 font-semibold">Uploaded Image Preview</h3>
          <div className="relative overflow-hidden rounded-xl">
            <img src={imageMeta.preview} alt="Uploaded groceries" className="w-full" />
            {imageMeta.boxes.map((box, index) => (
              <span
                key={`${box.name}-${index}`}
                className="absolute rounded border-2 border-primary bg-emerald-200/20 text-[10px] font-semibold text-emerald-900"
                style={{ left: `${box.x}%`, top: `${box.y}%`, width: `${box.width}%`, height: `${box.height}%` }}
              >
                {box.name}
              </span>
            ))}
          </div>
        </section>
      )}

      <ItemListBuilder items={items} onChange={setItems} onSearch={runComparison} />

      {loading && (
        <div className="grid gap-3 md:grid-cols-2">
          <SkeletonCard />
          <SkeletonCard />
        </div>
      )}
    </div>
  );
};

export default ListPage;
