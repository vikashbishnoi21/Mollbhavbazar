import { useMemo, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { jsPDF } from "jspdf";
import { useApp } from "../context/AppContext";
import { placeOrder, validatePincode } from "../services/api";

const CheckoutPage = () => {
  const { comparison, selectedPlatform, setOrder, setToast } = useApp();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const platformId = searchParams.get("platform") || selectedPlatform || "blinkit";
  const platformMeta = comparison?.platforms?.find((p) => p.id === platformId);
  const selectedItems = useMemo(() => {
    if (!comparison) return [];
    return comparison.items
      .map((item) => {
        const cell = item.prices[platformId];
        if (!cell?.available) return null;
        return {
          name: `${item.name} ${item.quantity}${item.unit}`,
          price: cell.price
        };
      })
      .filter(Boolean);
  }, [comparison, platformId]);

  const [step, setStep] = useState(1);
  const [address, setAddress] = useState(() => {
    const saved = localStorage.getItem("basketcheck_address");
    return saved
      ? JSON.parse(saved)
      : { fullAddress: "", pincode: "", city: "", phone: "", altPhone: "" };
  });
  const [payment, setPayment] = useState({ method: "upi", upiId: "", cardNumber: "", expiry: "", cvv: "" });
  const subtotal = selectedItems.reduce((sum, i) => sum + i.price, 0);
  const deliveryFee = platformMeta?.deliveryFee || 20;
  const total = subtotal + deliveryFee;

  const onValidatePincode = async () => {
    if (!address.pincode) return;
    try {
      const data = await validatePincode(address.pincode);
      setAddress((prev) => ({ ...prev, city: data.city || prev.city }));
    } catch (err) {
      setToast(err.message);
    }
  };

  const onContinue = () => {
    if (!address.fullAddress || !address.pincode || !address.phone) {
      setToast("Please complete address details.");
      return;
    }
    localStorage.setItem("basketcheck_address", JSON.stringify(address));
    setStep(2);
  };

  const createPdf = (orderData) => {
    const doc = new jsPDF();
    doc.setFontSize(14);
    doc.text("BasketCheck Receipt", 20, 20);
    doc.setFontSize(11);
    doc.text(`Order ID: ${orderData.orderId}`, 20, 30);
    doc.text(`Platform: ${orderData.platform}`, 20, 38);
    let y = 50;
    orderData.items.forEach((item) => {
      doc.text(`${item.name} - Rs ${item.price}`, 20, y);
      y += 8;
    });
    doc.text(`Delivery Fee: Rs ${orderData.deliveryFee}`, 20, y + 8);
    doc.text(`Total: Rs ${orderData.total}`, 20, y + 16);
    return doc.output("datauristring");
  };

  const onPlaceOrder = async () => {
    try {
      const orderData = await placeOrder({
        platform: platformId,
        items: selectedItems,
        address,
        payment,
        deliveryFee
      });
      const receiptPdf = createPdf(orderData);
      const withReceipt = { ...orderData, receiptPdf };
      setOrder(withReceipt);
      navigate("/order-success");
    } catch (err) {
      setToast(err.message);
    }
  };

  if (!comparison) return <div className="card text-sm">No cart found for checkout.</div>;

  return (
    <div className="space-y-4">
      {step === 1 && (
        <section className="card space-y-3">
          <h2 className="text-lg font-semibold">Step 1: Delivery Details</h2>
          <textarea
            value={address.fullAddress}
            onChange={(e) => setAddress({ ...address, fullAddress: e.target.value })}
            className="h-24 w-full rounded-xl border border-gray-200 p-3"
            placeholder="Full Address"
          />
          <div className="grid grid-cols-2 gap-2">
            <input
              value={address.pincode}
              onBlur={onValidatePincode}
              onChange={(e) => setAddress({ ...address, pincode: e.target.value })}
              className="rounded-xl border border-gray-200 px-3 py-2"
              placeholder="Pincode"
            />
            <input
              value={address.city}
              onChange={(e) => setAddress({ ...address, city: e.target.value })}
              className="rounded-xl border border-gray-200 px-3 py-2"
              placeholder="City"
            />
          </div>
          <input
            value={address.phone}
            onChange={(e) => setAddress({ ...address, phone: e.target.value })}
            className="w-full rounded-xl border border-gray-200 px-3 py-2"
            placeholder="Phone Number"
          />
          <input
            value={address.altPhone}
            onChange={(e) => setAddress({ ...address, altPhone: e.target.value })}
            className="w-full rounded-xl border border-gray-200 px-3 py-2"
            placeholder="Alternate Phone (optional)"
          />
          <button onClick={onContinue} className="pill-btn bg-accent text-white">
            Continue to Payment
          </button>
        </section>
      )}

      {step === 2 && (
        <section className="card space-y-4">
          <h2 className="text-lg font-semibold">Step 2: Payment</h2>
          <div className="space-y-2 rounded-xl bg-gray-50 p-3 text-sm">
            <label className="block">
              <input
                type="radio"
                name="payment"
                checked={payment.method === "upi"}
                onChange={() => setPayment({ ...payment, method: "upi" })}
                className="mr-2"
              />
              UPI
            </label>
            {payment.method === "upi" && (
              <input
                value={payment.upiId}
                onChange={(e) => setPayment({ ...payment, upiId: e.target.value })}
                className="w-full rounded-xl border border-gray-200 px-3 py-2"
                placeholder="Enter UPI ID"
              />
            )}
            <label className="block">
              <input
                type="radio"
                name="payment"
                checked={payment.method === "card"}
                onChange={() => setPayment({ ...payment, method: "card" })}
                className="mr-2"
              />
              Credit / Debit Card
            </label>
            {payment.method === "card" && (
              <div className="grid grid-cols-3 gap-2">
                <input
                  value={payment.cardNumber}
                  onChange={(e) => setPayment({ ...payment, cardNumber: e.target.value })}
                  className="col-span-3 rounded-xl border border-gray-200 px-3 py-2"
                  placeholder="Card Number"
                />
                <input
                  value={payment.expiry}
                  onChange={(e) => setPayment({ ...payment, expiry: e.target.value })}
                  className="rounded-xl border border-gray-200 px-3 py-2"
                  placeholder="MM/YY"
                />
                <input
                  value={payment.cvv}
                  onChange={(e) => setPayment({ ...payment, cvv: e.target.value })}
                  className="rounded-xl border border-gray-200 px-3 py-2"
                  placeholder="CVV"
                />
              </div>
            )}
            <label className="block">
              <input
                type="radio"
                name="payment"
                checked={payment.method === "cod"}
                onChange={() => setPayment({ ...payment, method: "cod" })}
                className="mr-2"
              />
              Cash on Delivery
            </label>
          </div>

          <div className="rounded-xl border border-gray-100 p-3 text-sm">
            <h3 className="mb-2 font-semibold">Order Summary</h3>
            {selectedItems.map((item) => (
              <div key={item.name} className="mb-1 flex justify-between">
                <span>{item.name}</span>
                <span>Rs {item.price}</span>
              </div>
            ))}
            <div className="mt-2 flex justify-between">
              <span>Delivery Fee</span>
              <span>Rs {deliveryFee}</span>
            </div>
            <div className="mt-2 flex justify-between font-bold">
              <span>Total</span>
              <span>Rs {total}</span>
            </div>
          </div>

          <button onClick={onPlaceOrder} className="pill-btn bg-primary text-white">
            PLACE ORDER
          </button>
        </section>
      )}
    </div>
  );
};

export default CheckoutPage;
