import { useNavigate } from "react-router-dom";
import ComparisonTable from "../components/ComparisonTable";
import { useApp } from "../context/AppContext";

const ComparePage = () => {
  const { comparison, setSelectedPlatform, setToast } = useApp();
  const navigate = useNavigate();

  const onBuy = (platformId) => {
    setSelectedPlatform(platformId);
    setToast(`Proceeding with ${platformId}`);
    navigate(`/checkout?platform=${platformId}`);
  };

  if (!comparison) {
    return (
      <div className="card">
        <p className="text-sm text-gray-600">No comparison data yet. Build your list first.</p>
      </div>
    );
  }

  return <ComparisonTable comparison={comparison} onBuy={onBuy} />;
};

export default ComparePage;
