import { useApp } from "../context/AppContext";

const OrderSuccessPage = () => {
  const { order } = useApp();
  if (!order) return <div className="card text-sm">No recent order found.</div>;

  return (
    <section className="card space-y-3">
      <h2 className="text-xl font-bold text-primary">Order Confirmed</h2>
      <p className="text-sm">Order ID: {order.orderId}</p>
      <p className="text-sm">Estimated Delivery: {order.eta}</p>
      <p className="text-sm font-semibold">Total: Rs {order.total}</p>
      <a
        href={order.receiptPdf}
        download={`basketcheck-${order.orderId}.pdf`}
        className="pill-btn inline-block bg-accent text-white"
      >
        Download Receipt as PDF
      </a>
    </section>
  );
};

export default OrderSuccessPage;
