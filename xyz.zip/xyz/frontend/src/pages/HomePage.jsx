import SearchTabs from "../components/SearchTabs";

const HomePage = () => {
  return (
    <div className="space-y-4">
      <section className="card bg-gradient-to-r from-emerald-500 to-emerald-400 text-white">
        <h1 className="text-2xl font-bold">Compare Grocery Prices in Seconds</h1>
        <p className="mt-1 text-sm text-emerald-50">
          Use image, voice, or text to build your basket and find the best platform instantly.
        </p>
      </section>
      <SearchTabs />
    </div>
  );
};

export default HomePage;
