const API_BASE = import.meta.env.VITE_API_BASE || "http://localhost:4000/api";

const parse = async (res) => {
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || "Request failed");
  return data;
};

export const searchFromText = async (text) =>
  parse(
    await fetch(`${API_BASE}/search/text`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text })
    })
  );

export const searchFromVoice = async (transcript) =>
  parse(
    await fetch(`${API_BASE}/search/voice`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ transcript })
    })
  );

export const searchFromImage = async (file) => {
  const formData = new FormData();
  formData.append("image", file);
  return parse(
    await fetch(`${API_BASE}/search/image`, {
      method: "POST",
      body: formData
    })
  );
};

export const getSuggestions = async (q) => parse(await fetch(`${API_BASE}/search/suggest?q=${encodeURIComponent(q)}`));
export const validatePincode = async (pin) => parse(await fetch(`${API_BASE}/meta/pincode/${pin}`));

export const comparePrices = async (items, pincode) =>
  parse(
    await fetch(`${API_BASE}/compare`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ items, pincode })
    })
  );

export const placeOrder = async (payload) =>
  parse(
    await fetch(`${API_BASE}/checkout/place-order`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    })
  );
