/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        primary: "#2ECC71",
        accent: "#F39C12",
        page: "#F8F9FA"
      },
      boxShadow: {
        soft: "0 8px 24px rgba(0, 0, 0, 0.06)"
      },
      keyframes: {
        slidein: {
          "0%": { opacity: "0", transform: "translateY(20px)" },
          "100%": { opacity: "1", transform: "translateY(0)" }
        }
      },
      animation: {
        slidein: "slidein 0.35s ease"
      }
    }
  },
  plugins: []
};
