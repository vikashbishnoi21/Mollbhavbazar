# BasketCheck

Full-stack grocery price comparison app with guest checkout.

## Tech
- Frontend: React + Vite + Tailwind
- Backend: Node.js + Express

## Run
1. Install Node.js 18+
2. Backend:
   - `cd backend`
   - `copy .env.example .env`
   - `npm install`
   - `npm run dev`
3. Frontend:
   - `cd frontend`
   - `npm install`
   - `npm run dev`
4. Open `http://localhost:5173`

## API Base
Frontend uses `VITE_API_BASE` (default `http://localhost:4000/api`).

## Implemented Features
- Image/voice/text search tabs
- Item list builder with quantity + unit edits
- Price comparison across Zepto, Blinkit, Instamart, BigBasket
- Cheapest badge and color coding
- Platform totals, delivery fee/time, best overall deal
- Availability toggle and out-of-stock handling
- 2-step guest checkout with localStorage address memory
- Pincode validation endpoint
- Order confirmation + PDF receipt download
