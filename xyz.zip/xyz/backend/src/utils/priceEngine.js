import { ITEM_CATALOG, PLATFORM_META } from "../data/catalog.js";

const catalogMap = new Map(ITEM_CATALOG.map((item) => [item.name, item]));

const hashCode = (value) =>
  value.split("").reduce((acc, ch) => {
    return (acc * 31 + ch.charCodeAt(0)) % 100000;
  }, 7);

const itemMultiplier = (item) => {
  const unit = item.unit?.toLowerCase() || "unit";
  if (unit.includes("kg")) return item.quantity || 1;
  if (unit.includes("g")) return (item.quantity || 250) / 500;
  if (unit.includes("1l")) return item.quantity || 1;
  return item.quantity || 1;
};

export const comparePrices = (items, pincode = "000000") => {
  const normalizedItems = items.map((item) => ({
    name: item.name.toLowerCase().trim(),
    quantity: Number(item.quantity || 1),
    unit: (item.unit || "unit").toLowerCase(),
    size: item.size || "medium"
  }));

  const comparedItems = normalizedItems.map((item) => {
    const catalog = catalogMap.get(item.name) || { basePrice: 50 };
    const base = catalog.basePrice * itemMultiplier(item);
    const prices = {};
    let bestPlatform = null;
    let bestPrice = Number.POSITIVE_INFINITY;

    for (const platform of PLATFORM_META) {
      const h = hashCode(`${item.name}-${platform.id}-${pincode}`);
      const available = h % 7 !== 0;
      if (!available) {
        prices[platform.id] = { available: false, price: null };
        continue;
      }
      const volatility = ((h % 9) - 4) * 0.5;
      const final = Math.max(1, Math.round(base * platform.factor + volatility));
      prices[platform.id] = { available: true, price: final };
      if (final < bestPrice) {
        bestPrice = final;
        bestPlatform = platform.id;
      }
    }

    return { ...item, prices, bestPlatform };
  });

  const totals = {};
  for (const platform of PLATFORM_META) {
    totals[platform.id] = comparedItems.reduce((sum, item) => {
      const p = item.prices[platform.id];
      return sum + (p?.available ? p.price : 0);
    }, 0);
  }

  let bestOverall = PLATFORM_META[0].id;
  for (const platform of PLATFORM_META) {
    if (totals[platform.id] < totals[bestOverall]) bestOverall = platform.id;
  }

  return {
    platforms: PLATFORM_META,
    items: comparedItems,
    totals,
    bestOverall
  };
};
