import { ITEM_CATALOG } from "../data/catalog.js";

const NAME_SET = new Set(ITEM_CATALOG.map((item) => item.name));

const UNIT_SYNONYMS = {
  litre: "1l",
  liter: "1l",
  l: "1l",
  ml: "500ml",
  kg: "kg",
  g: "g"
};

const tidyName = (raw) =>
  raw
    .trim()
    .toLowerCase()
    .replace(/[^a-z\s]/g, " ")
    .replace(/\s+/g, " ");

const inferCatalogName = (chunk) => {
  const normalized = tidyName(chunk);
  for (const known of NAME_SET) {
    if (normalized.includes(known)) return known;
  }
  return normalized.split(" ").slice(0, 2).join(" ").trim() || "item";
};

const inferQuantityAndUnit = (chunk) => {
  const cleaned = chunk.toLowerCase();
  const qMatch = cleaned.match(/(\d+(\.\d+)?)\s*(kg|g|l|ml|litre|liter)?/i);
  if (!qMatch) return { quantity: 1, unit: "unit", size: "medium" };
  const quantity = Number(qMatch[1]) || 1;
  const rawUnit = (qMatch[3] || "unit").toLowerCase();
  const mappedUnit = UNIT_SYNONYMS[rawUnit] || rawUnit;
  const size =
    mappedUnit === "kg" && quantity >= 2
      ? "2kg"
      : mappedUnit === "1l"
      ? "1l"
      : mappedUnit || "medium";
  return { quantity, unit: mappedUnit, size };
};

export const parseFreeTextToItems = (input = "") => {
  if (!input.trim()) return [];
  const chunks = input
    .split(/\n|,| and /i)
    .map((part) => part.trim())
    .filter(Boolean);

  return chunks.map((chunk) => {
    const name = inferCatalogName(chunk);
    const { quantity, unit, size } = inferQuantityAndUnit(chunk);
    return { name, quantity, unit, size };
  });
};

export const parseVoiceTextToItems = (transcript = "") => parseFreeTextToItems(transcript);
