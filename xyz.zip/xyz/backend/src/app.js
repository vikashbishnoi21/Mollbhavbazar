import express from "express";
import cors from "cors";
import searchRoutes from "./routes/searchRoutes.js";
import compareRoutes from "./routes/compareRoutes.js";
import checkoutRoutes from "./routes/checkoutRoutes.js";
import metaRoutes from "./routes/metaRoutes.js";

const app = express();

app.use(
  cors({
    origin: process.env.FRONTEND_ORIGIN || "http://localhost:5173"
  })
);
app.use(express.json({ limit: "2mb" }));

app.get("/api/health", (_req, res) => res.json({ ok: true }));
app.use("/api/search", searchRoutes);
app.use("/api/compare", compareRoutes);
app.use("/api/checkout", checkoutRoutes);
app.use("/api/meta", metaRoutes);

export default app;
