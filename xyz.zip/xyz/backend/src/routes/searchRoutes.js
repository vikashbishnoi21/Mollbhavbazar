import express from "express";
import multer from "multer";
import { ITEM_CATALOG } from "../data/catalog.js";
import { parseFreeTextToItems, parseVoiceTextToItems } from "../utils/parse.js";

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage() });

router.get("/suggest", (req, res) => {
  const q = (req.query.q || "").toString().toLowerCase().trim();
  if (!q) return res.json({ suggestions: ITEM_CATALOG.slice(0, 8).map((i) => i.name) });
  const suggestions = ITEM_CATALOG.map((item) => item.name).filter((name) => name.includes(q));
  return res.json({ suggestions: suggestions.slice(0, 10) });
});

router.post("/text", (req, res) => {
  const { text } = req.body || {};
  const items = parseFreeTextToItems(text);
  return res.json({ items });
});

router.post("/voice", (req, res) => {
  const { transcript } = req.body || {};
  const items = parseVoiceTextToItems(transcript);
  return res.json({ items });
});

router.post("/image", upload.single("image"), async (req, res) => {
  const file = req.file;
  if (!file) return res.status(400).json({ message: "Image is required." });

  const filename = file.originalname.toLowerCase();
  const detectedNames = ITEM_CATALOG.map((item) => item.name).filter((name) => filename.includes(name));
  const picked = detectedNames.length ? detectedNames : ["onions", "milk", "bread"];
  const items = picked.map((name) => ({ name, quantity: 1, unit: "unit", size: "medium" }));
  const boxes = picked.map((name, index) => ({
    name,
    x: 8 + index * 20,
    y: 8 + index * 10,
    width: 24,
    height: 18
  }));

  return res.json({ items, boxes });
});

export default router;
