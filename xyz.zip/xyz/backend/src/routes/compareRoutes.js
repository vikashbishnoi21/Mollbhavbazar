import express from "express";
import { comparePrices } from "../utils/priceEngine.js";

const router = express.Router();

router.post("/", (req, res) => {
  const { items = [], pincode = "" } = req.body || {};
  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ message: "At least one item is required." });
  }
  if (!/^\d{6}$/.test(pincode)) {
    return res.status(400).json({ message: "Please enter a valid 6-digit pincode first." });
  }

  const comparison = comparePrices(items, pincode);
  return res.json(comparison);
});

export default router;
