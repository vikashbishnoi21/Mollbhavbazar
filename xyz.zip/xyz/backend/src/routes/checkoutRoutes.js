import express from "express";

const router = express.Router();

router.post("/place-order", (req, res) => {
  const { platform, items, address, payment, deliveryFee = 0 } = req.body || {};
  if (!platform || !Array.isArray(items) || !address?.fullAddress || !address?.phone) {
    return res.status(400).json({ message: "Missing required checkout fields." });
  }
  if (!payment?.method) {
    return res.status(400).json({ message: "Payment method is required." });
  }

  const subtotal = items.reduce((sum, item) => sum + Number(item.price || 0), 0);
  const total = subtotal + Number(deliveryFee || 0);
  const orderId = `BC${Date.now().toString().slice(-8)}`;
  const eta = "15-35 minutes";

  return res.status(201).json({
    orderId,
    eta,
    platform,
    subtotal,
    deliveryFee,
    total,
    items,
    address
  });
});

export default router;
