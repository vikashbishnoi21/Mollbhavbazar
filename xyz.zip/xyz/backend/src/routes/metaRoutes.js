import express from "express";
import { CITY_BY_PIN_PREFIX } from "../data/catalog.js";

const router = express.Router();

router.get("/pincode/:pin", (req, res) => {
  const pin = (req.params.pin || "").trim();
  if (!/^\d{6}$/.test(pin)) {
    return res.status(400).json({ valid: false, message: "Invalid pincode format." });
  }
  const city = CITY_BY_PIN_PREFIX[pin[0]] || "Metro City";
  return res.json({ valid: true, city, serviceable: true });
});

export default router;
