export const UNIT_OPTIONS = [
  "unit",
  "small",
  "medium",
  "large",
  "250g",
  "500g",
  "1kg",
  "2kg",
  "500ml",
  "1l",
  "2l",
  "kg",
  "g",
  "litre"
];

export const ITEM_CATALOG = [
  { name: "onions", basePrice: 28, defaultUnit: "kg" },
  { name: "potatoes", basePrice: 30, defaultUnit: "kg" },
  { name: "tomatoes", basePrice: 36, defaultUnit: "kg" },
  { name: "milk", basePrice: 24, defaultUnit: "1l" },
  { name: "bread", basePrice: 42, defaultUnit: "large" },
  { name: "eggs", basePrice: 72, defaultUnit: "12 unit" },
  { name: "rice", basePrice: 58, defaultUnit: "kg" },
  { name: "atta", basePrice: 52, defaultUnit: "kg" },
  { name: "sugar", basePrice: 44, defaultUnit: "kg" },
  { name: "salt", basePrice: 20, defaultUnit: "kg" },
  { name: "curd", basePrice: 38, defaultUnit: "500g" },
  { name: "paneer", basePrice: 92, defaultUnit: "500g" },
  { name: "banana", basePrice: 48, defaultUnit: "dozen" },
  { name: "apple", basePrice: 120, defaultUnit: "kg" }
];

export const PLATFORM_META = [
  { id: "zepto", name: "Zepto", deliveryFee: 18, deliveryTime: "10-14 min", factor: 0.98 },
  { id: "blinkit", name: "Blinkit", deliveryFee: 20, deliveryTime: "12-18 min", factor: 1.0 },
  { id: "instamart", name: "Instamart", deliveryFee: 24, deliveryTime: "18-24 min", factor: 1.03 },
  { id: "bigbasket", name: "BigBasket", deliveryFee: 16, deliveryTime: "35-50 min", factor: 0.97 }
];

export const CITY_BY_PIN_PREFIX = {
  "1": "Delhi",
  "2": "Mumbai",
  "3": "Pune",
  "4": "Hyderabad",
  "5": "Bengaluru",
  "6": "Chennai",
  "7": "Kolkata",
  "8": "Ahmedabad",
  "9": "Jaipur"
};
